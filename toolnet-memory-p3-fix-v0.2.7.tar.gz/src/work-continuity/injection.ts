import {
  existsSync,
  mkdirSync,
  readFileSync,
} from "node:fs";

import {
  homedir,
} from "node:os";

import {
  dirname,
  join,
} from "node:path";

import type {
  ProjectManifest,
} from "../core/types.js";

import type {
  StorageProvider,
} from "../storage/types.js";

import {
  writeJsonAtomic,
} from "../session/utils.js";

import {
  getStartupBriefForInjection,
  refreshStartupBriefCache,
} from "./brief-cache.js";

interface InjectionMarker {
  digest:
    string;

  injectedAt:
    string;
}

function markerFile(
  project:
    ProjectManifest,

  conversationId:
    string,

  overrideDirectory?:
    string,
) {
  const base =
    overrideDirectory ??
    join(
      homedir(),
      ".config",
      "toolnet-memory",
      "injections",
      "agy",
    );

  return join(
    base,
    `${project.id}-${conversationId}.json`,
  );
}

function loadMarker(
  file:
    string,
): InjectionMarker |
null {
  if (
    !existsSync(file)
  ) {
    return null;
  }

  try {
    return JSON.parse(
      readFileSync(
        file,
        "utf8",
      ),
    ) as
      InjectionMarker;
  } catch {
    return null;
  }
}

export async function buildAgyPreInvocationOutput(
  options: {
    project:
      ProjectManifest;

    storage:
      StorageProvider;

    conversationId:
      string;

    invocationNum?:
      number;

    markerDirectory?:
      string;

    now?:
      number;

    resumeAfterMs?:
      number;
  },
): Promise<
  Record<
    string,
    unknown
  >
> {
  const now =
    options.now ??
    Date.now();

  const resumeAfterMs =
    options.resumeAfterMs ??
    6 * 60 * 60 * 1000;

  const markerPath =
    markerFile(
      options.project,
      options.conversationId,
      options.markerDirectory,
    );

  const marker =
    loadMarker(
      markerPath,
    );

  const markerTime =
    marker
      ? Date.parse(
          marker.injectedAt,
        )
      : 0;

  const age =
    markerTime
      ? now -
        markerTime
      : Number.POSITIVE_INFINITY;

  /*
   * Avoid duplicate injection on immediate retry.
   */
  if (
    marker &&
    age <
      60_000
  ) {
    return {};
  }

  const firstInvocation =
    options.invocationNum ===
      0;

  const resumedAfterPause =
    age >=
    resumeAfterMs;

  if (
    marker &&
    !firstInvocation &&
    !resumedAfterPause
  ) {
    return {};
  }

  /*
   * On the first model invocation of a new Agy conversation, build the
   * brief from durable work state/handoff instead of trusting a possibly
   * stale derived cache. Later resume injections may use the cache.
   */
  const cache =
    firstInvocation
      ? await refreshStartupBriefCache(
          options.project,
          options.storage,
          900,
        )
      : await getStartupBriefForInjection(
          options.project,
          options.storage,
          900,
        );

  if (
    !cache?.text
  ) {
    return {};
  }

  mkdirSync(
    dirname(
      markerPath,
    ),
    {
      recursive:
        true,
    },
  );

  writeJsonAtomic(
    markerPath,
    {
      digest:
        cache.digest,

      injectedAt:
        new Date(now)
          .toISOString(),
    },
  );

  return {
    injectSteps: [
      {
        ephemeralMessage:
          `${cache.text}\n\n[TOOLNET CONTINUITY INSTRUCTION]\nThe context above is durable state from the previous ToolNet session for this project. Treat it as known project history. If the user says "continue", "continue the previous task", "task from earlier", or equivalent, continue from CURRENT OBJECTIVE / CURRENT TASK / NEXT ACTIONS above. Do not ask the user to repeat information already present in this context.`,
      },
    ],
  };
}


export async function buildCodexSessionStartOutput(
  options: {
    project:
      ProjectManifest;

    storage:
      StorageProvider;
  },
): Promise<
  Record<
    string,
    unknown
  >
> {
  const cache =
    await getStartupBriefForInjection(
      options.project,
      options.storage,
      900,
    );

  if (
    !cache?.text
  ) {
    return {};
  }

  return {
    hookSpecificOutput: {
      hookEventName:
        "SessionStart",

      additionalContext:
        cache.text,
    },
  };
}
